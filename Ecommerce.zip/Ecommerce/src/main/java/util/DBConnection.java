package util;
import java.sql.*;
public class DBConnection {
	
		private static Connection conn;
		private DBConnection() {

		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db","root","PHW#84#jeor");
		System.out.println("connected to the database");
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
		public static Connection getConnect() {
			DBConnection d1 = new DBConnection();
			return conn;
		}

	}
