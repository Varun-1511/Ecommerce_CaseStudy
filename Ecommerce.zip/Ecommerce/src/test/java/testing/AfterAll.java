package testing;

public @interface AfterAll {

}
