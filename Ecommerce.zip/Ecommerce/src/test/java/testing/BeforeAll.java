package testing;

public @interface BeforeAll {

}
